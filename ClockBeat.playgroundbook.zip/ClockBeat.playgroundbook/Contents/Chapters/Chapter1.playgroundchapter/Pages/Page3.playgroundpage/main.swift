//#-hidden-code
import SpriteKit
showClock()
currentPage = Page.third
sceneViewController.skScene.playButton.fillColor = .white
sceneViewController.skScene.playButton.fillTexture = SKTexture.init(image: UIImage(named: "Play")!)
//#-end-hidden-code
//#-code-completion(everything, show)
/*:
 **Rhythm:** Let's make a dance rhythm?
 
 OK, now you have more options of sounds to make something great... I trust you!
 
 Stay fantastic and make a goooooooood 'Rhythm', I'm trying to show that it's easier than they looks :)
 
 Thank you for enjoy this playground. Many things in our lives are easier than looks... programming, cooking... including music, even more when it's your passion like it's my passion.
 
 In any moment... Make music! Play music!
 
 Congratulations, and I'll see you in WWDC 2020!
*/

