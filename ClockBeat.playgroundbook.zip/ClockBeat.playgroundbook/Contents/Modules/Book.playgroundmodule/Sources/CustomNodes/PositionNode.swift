import SpriteKit

public class PositionNode: SKShapeNode{
    public var isOcupped = false
    public var occupedWith: SoundElement? = nil
}
